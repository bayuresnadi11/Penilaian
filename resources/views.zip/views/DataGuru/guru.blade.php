@extends('layouts.layout')

@section('content')
<div class="content">
    <div class="container mt-4">

        {{-- Header --}}
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h2 class="fw-bold text-primary">Data Guru</h2>
                <p class="text-muted m-0">Kelola data guru dengan mudah dan efisien</p>
            </div>
            <a href="{{ route('dataguru.create') }}" class="btn btn-primary">
                <i class="bi bi-person-plus"></i> Tambah Guru
            </a>
        </div>

        {{-- Pencarian dan Filter --}}
        <div class="d-flex gap-2 mb-3">
            <form action="{{ route('dataguru.guru') }}" method="GET" class="d-flex flex-grow-1">
                <input type="text" name="search" class="form-control me-2" placeholder="Cari nama atau NIP..." value="{{ request('search') }}">
                <button type="submit" class="btn btn-primary">Cari</button>
            </form>
            <button class="btn btn-outline-secondary">
                <i class="bi bi-filter"></i> Filter
            </button>
            <div class="dropdown">
                <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                    <i class="bi bi-download"></i> Export
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#">Export Excel</a></li>
                    <li><a class="dropdown-item" href="#">Export PDF</a></li>
                </ul>
            </div>
        </div>

        {{-- Tabel Data Guru --}}
        <div class="table-responsive shadow-sm rounded bg-white p-3">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Nama</th>
                        <th>NIP</th>
                        <th>Email</th>
                        <th>No. Telp</th>
                        <th>Jenis Kelamin</th>
                        <th>Tanggal Lahir</th>
                        <th>Mapel</th>
                        <th class="text-end">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($guru as $g)
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td class="d-flex align-items-center gap-2">
                            <div class="rounded-circle bg-light text-danger fw-bold text-center border border-danger"
                                 style="width: 32px; height: 32px; line-height: 32px;">
                                {{ strtoupper(substr($g->nama, 0, 1)) }}
                            </div>
                            <div>
                                <strong>{{ $g->nama }}</strong><br>
                                <small class="text-muted">ID: {{ $g->id }}</small>
                            </div>
                        </td>
                        <td>{{ $g->nip }}</td>
                        <td>{{ $g->email }}</td>
                        <td>{{ $g->no_telp }}</td>
                        <td>{{ $g->jenis_kelamin }}</td>
                        <td>{{ \Carbon\Carbon::parse($g->tgl_lahir)->translatedFormat('d M Y') }}</td>
                        <td>
                            <span class="badge bg-info-subtle text-primary fw-semibold">
                                {{ $g->mata_pelajaran->nama ?? 'Belum Diatur' }}
                            </span>
                        </td>
                        <td class="text-end">
                            <div class="dropdown">
                                <button class="btn btn-outline-secondary btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                    Aksi
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li><a class="dropdown-item d-flex align-items-center" href="#"><i class="bi bi-eye me-2"></i> Detail</a></li>
                                    <li><a class="dropdown-item d-flex align-items-center" href="{{ route('dataguru.edit', $g->id) }}"><i class="bi bi-pencil me-2"></i> Edit</a></li>
                                    <li>
                                        <form action="{{ route('dataguru.destroy', $g->id) }}" method="POST" onsubmit="return confirm('Yakin ingin menghapus data ini?')">
                                            @csrf
                                            @method('DELETE')
                                            <button class="dropdown-item d-flex align-items-center text-danger" type="submit">
                                                <i class="bi bi-trash me-2"></i> Hapus
                                            </button>
                                        </form>
                                    </li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                    @endforeach
                    @if($guru->isEmpty())
                    <tr>
                        <td colspan="9" class="text-center text-muted">Tidak ada data guru ditemukan.</td>
                    </tr>
                    @endif
                </tbody>
            </table>
        </div>
    </div>
</div>
