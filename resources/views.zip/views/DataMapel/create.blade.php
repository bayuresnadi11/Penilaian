 @extends('layouts.layout')

@section('content')
<div class="container mt-4">
    <h4>Tambah Mata Pelajaran</h4>

    <div class="card mt-3">
        <div class="card-body">
            <form action="{{ route('datamapel.store') }}" method="POST">
                @csrf
                <div class="mb-3">
                    <label for="kode" class="form-label">Kode Mapel</label>
                    <input type="text" name="kode" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="nama" class="form-label">Nama Mapel</label>
                    <input type="text" name="nama" class="form-control" required>
                </div>
                <button class="btn btn-success">Simpan</button>
                <a href="{{ route('datamapel.index') }}" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>
</div>
@endsection
