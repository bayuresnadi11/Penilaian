@extends('layouts.layout')

@section('content')
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0">Data Mata Pelajaran</h4>
        <a href="{{ route('datamapel.create') }}" class="btn btn-primary">+ Tambah Mapel</a>
    </div>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <div class="card">
        <div class="card-body table-responsive">
            <table class="table table-bordered table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>Kode</th>
                        <th>Mata Pelajaran</th>
                        <th class="text-center" width="150px">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($mapel as $index => $m)
                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td>{{ $m->kode }}</td>
                            <td>{{ $m->nama }}</td>
                            <td class="text-center">
                                <a href="{{ route('datamapel.edit', $m->id) }}" class="btn btn-sm btn-warning">Edit</a>
                                <form action="{{ route('datamapel.destroy', $m->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin dihapus?')">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                    @if($mapel->isEmpty())
                        <tr><td colspan="4" class="text-center">Belum ada data mata pelajaran.</td></tr>
                    @endif
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
