@extends('layouts.layout')

@section('content')
<div class="ms-auto p-4" style="max-width: 100%;">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3">Data Pengguna</h1>
            <p class="text-muted mb-0">Kelola data pengguna dengan mudah dan efisien</p>
        </div>
        <a href="{{ route('datauser.user') }}" class="btn btn-primary">
            <i class="bi bi-person-plus"></i> Tambah Pengguna
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <table class="table table-bordered table-striped align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Role</th>
                        <th class="text-end">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($users as $user)
                    <tr>
                        <td>{{ $user->id }}</td>
                        <td>{{ $user->username }}</td>
                        <td>{{ ucfirst($user->role) }}</td>
                        <td class="text-end">
                            <a href="" class="btn btn-sm btn-warning">Edit</a>
                            <form action="{{ route('datauser.user', $user->id) }}" method="POST" class="d-inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-danger"
                                    onclick="return confirm('Yakin ingin menghapus pengguna ini?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>

            <div class="mt-3">
                {{ $users->links() }}
            </div>
        </div>
    </div>
</div>

