@extends('layouts.layout')
@section('content')
<div class="container">
    <h2 class="mb-4">Edit Data Murid</h2>

    <form action="{{ route('murid.update', $murid->id) }}" method="POST">
        @csrf
        @method('PUT')

        <div class="mb-3">
            <label for="nama" class="form-label">Nama:</label>
            <input type="text" name="nama" id="nama" class="form-control" value="{{ $murid->nama }}" required>
        </div>

        <div class="mb-3">
            <label for="nis" class="form-label">NIS:</label>
            <input type="text" name="nis" id="nis" class="form-control" value="{{ $murid->nis }}" required>
        </div>

        <div class="mb-3">
            <label for="kelas" class="form-label">Kelas:</label>
            <input type="text" name="kelas" id="kelas" class="form-control" value="{{ $murid->kelas }}" required>
        </div>

        <div class="mb-3">
            <label for="no_telp" class="form-label">No. Telp:</label>
            <input type="text" name="no_telp" id="no_telp" class="form-control" value="{{ $murid->no_telp }}">
        </div>

        <div class="mb-3">
            <label for="jenis_kelamin" class="form-label">Jenis Kelamin:</label>
            <select name="jenis_kelamin" id="jenis_kelamin" class="form-select">
                <option value="L" {{ $murid->jenis_kelamin == 'L' ? 'selected' : '' }}>Laki-laki</option>
                <option value="P" {{ $murid->jenis_kelamin == 'P' ? 'selected' : '' }}>Perempuan</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="tgl_lahir" class="form-label">Tanggal Lahir:</label>
            <input type="date" name="tgl_lahir" id="tgl_lahir" class="form-control" value="{{ $murid->tgl_lahir }}">
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
        <a href="{{ route('datamurid.murid') }}" class="btn btn-secondary">Batal</a>
    </form>
</div>
@endsection
