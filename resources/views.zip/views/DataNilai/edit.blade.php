@extends('layouts.layout')

@section('content')
<div class="container">
    <h4>Edit Nilai</h4>
    <form action="{{ route('nilai.update', $nilai->id) }}" method="POST">
        @csrf @method('PUT')
        @include('nilai.form', ['nilai' => $nilai])
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
@endsection
