@extends('layouts.layout')

@section('content')
<div class="container">
    <h4>Data Nilai</h4>
    <a href="{{ route('nilai.create') }}" class="btn btn-primary mb-3">Tambah Nilai</a>

    @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Guru</th>
                <th>Murid</th>
                <th>Mata Pelajaran</th>
                <th>Nilai</th>
                <th>Predikat</th>
                <th>Semester</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach($nilai as $n)
            <tr>
                <td>{{ $n->id }}</td>
                <td>{{ $n->id_guru }}</td>
                <td>{{ $n->id_murid }}</td>
                <td>{{ $n->id_mata_pelajaran }}</td>
                <td>{{ $n->nilai }}</td>
                <td>{{ $n->predikat }}</td>
                <td>{{ $n->semester }}</td>
                <td>
                    <a href="{{ route('nilai.edit', $n->id) }}" class="btn btn-sm btn-warning">Edit</a>
                    <form action="{{ route('nilai.destroy', $n->id) }}" method="POST" style="display:inline;">
                        @csrf @method('DELETE')
                        <button onclick="return confirm('Yakin hapus?')" class="btn btn-sm btn-danger">Hapus</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>

    {{ $nilai->links() }}
</div>
@endsection
