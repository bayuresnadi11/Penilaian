@extends('layouts.layout')

@section('content')
<div class="container">
    <h4>Tambah Nilai</h4>
    <form action="{{ route('nilai.store') }}" method="POST">
        @csrf
        @include('nilai.form')
        <button type="submit" class="btn btn-success">Simpan</button>
    </form>
</div>
@endsection
