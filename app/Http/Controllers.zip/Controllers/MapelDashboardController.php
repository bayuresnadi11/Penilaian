<?php

namespace App\Http\Controllers;

use App\Models\MataPelajaran;
use Illuminate\Http\Request;

class MapelDashboardController extends Controller
{
    public function index()
    {
        $mapel = MapelDashboardController::all(); // ✅ perbaikan di sini
        return view('datamapel.index', compact('mapel'));
    }

    public function create()
    {
        return view('datamapel.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'kode' => 'required|unique:mata_pelajaran,kode|max:10',
            'nama' => 'required|string|max:255',
        ]);

        MapelDashboardControlle::create($request->all());

        return redirect()->route('datamapel.index')->with('success', 'Data mapel berhasil ditambahkan.');
    }

    public function edit($id)
    {
        $mapel = Mata_Pelajaran::findOrFail($id);
        return view('datamapel.edit', compact('mapel'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'kode' => 'required|max:10|unique:mata_pelajaran,kode,' . $id,
            'nama' => 'required|string|max:255',
        ]);

        $mapel = Mata_Pelajaran::findOrFail($id);
        $mapel->update($request->all());

        return redirect()->route('datamapel.index')->with('success', 'Data mapel berhasil diperbarui.');
    }

    public function destroy($id)
    {
        Mata_Pelajaran::destroy($id);
        return back()->with('success', 'Data mapel berhasil dihapus.');
    }
}
