<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Murid;
use App\Models\Nilai;
use App\Models\User;

class MuridDashboardController extends Controller
{
    // Tampilkan semua murid (dengan pencarian dan pagination)
    public function index(Request $request)
    {
        $keyword = $request->input('keyword');

        $murid = Murid::when($keyword, function ($query) use ($keyword) {
                        $query->where('nama', 'like', "%{$keyword}%")
                              ->orWhere('nis', 'like', "%{$keyword}%");
                    })
                    ->orderBy('id', 'asc') // urutan dari 1 ke atas
                    ->paginate(10); // 10 data per halaman

        return view('datamurid.murid', compact('murid'));
    }

    // Tampilkan form tambah murid
    public function create()
    {
        $users = User::all(); // Ambil semua user (atau filter sesuai kebutuhan)
        return view('datamurid.create', compact('users'));
    }

    // Simpan data murid baru
    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'nis' => 'required|numeric|unique:murid,nis',
            'kelas' => 'required|string|max:50',
            'no_telp' => 'nullable|string|max:20',
            'jenis_kelamin' => 'required|in:L,P',
            'tgl_lahir' => 'required|date',
            'id_user' => 'required|exists:users,id',
        ]);

        Murid::create($request->all());

        return redirect()->route('datamurid.murid')->with('success', 'Data murid berhasil ditambahkan.');
    }

    // Tampilkan form edit murid
    public function edit($id)
    {
        $murid = Murid::findOrFail($id);
        return view('datamurid.edit', compact('murid'));
    }

    // Simpan perubahan data murid
    public function update(Request $request, $id)
    {
        $murid = Murid::findOrFail($id);

        $request->validate([
            'nama' => 'required|string|max:255',
            'nis' => 'required|numeric|unique:murid,nis,' . $id,
            'kelas' => 'required|string|max:50',
            'no_telp' => 'nullable|string|max:20',
            'jenis_kelamin' => 'required|in:L,P',
            'tgl_lahir' => 'required|date',
        ]);

        $murid->update($request->all());

        return redirect()->route('murid.index')->with('success', 'Data murid berhasil diperbarui.');
    }

    // Hapus data murid
    public function destroy($id)
    {
        $murid = Murid::findOrFail($id);
        $murid->delete();

        return redirect()->route('murid.index')->with('success', 'Data murid berhasil dihapus.');
    }
}
