<?php

namespace App\Http\Controllers;

use App\Models\Nilai;
use Illuminate\Http\Request;

class NilaiDashboardController extends Controller
{
    public function index()
    {
        $nilai = Nilai::paginate(10);
        return view('datanilai.nilai', compact('nilai'));
    }

    public function create()
    {
        return view('nilai.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'id_guru' => 'required|integer',
            'id_murid' => 'required|integer',
            'id_mata_pelajaran' => 'required|integer',
            'nilai' => 'required|integer',
            'predikat' => 'required|string|max:2',
            'semester' => 'required|integer'
        ]);

        Nilai::create($request->all());
        return redirect()->route('nilai.index')->with('success', 'Nilai berhasil ditambahkan.');
    }

    public function edit($id)
    {
        $nilai = Nilai::findOrFail($id);
        return view('nilai.edit', compact('nilai'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'id_guru' => 'required|integer',
            'id_murid' => 'required|integer',
            'id_mata_pelajaran' => 'required|integer',
            'nilai' => 'required|integer',
            'predikat' => 'required|string|max:2',
            'semester' => 'required|integer'
        ]);

        $nilai = Nilai::findOrFail($id);
        $nilai->update($request->all());
        return redirect()->route('nilai.index')->with('success', 'Nilai berhasil diperbarui.');
    }

    public function destroy($id)
    {
        Nilai::destroy($id);
        return redirect()->route('nilai.index')->with('success', 'Nilai berhasil dihapus.');
    }
}
