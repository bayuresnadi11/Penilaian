<?php

namespace App\Http\Controllers;

use App\Models\Guru;
use Illuminate\Http\Request;

class GuruDashboardController extends Controller
{
    public function index()
    {
        $guru = Guru::all();
        return view('dataguru.guru', compact('guru'));
    }

    public function create()
    {
        return view('dataguru.create');
    }

    public function store(Request $request)
    {
        Guru::create($request->all());
        return redirect()->route('dataguru.guru')->with('success', 'Data guru berhasil ditambahkan.');
    }

    public function edit($id)
    {
        $guru = Guru::findOrFail($id);
        return view('dataguru.edit', compact('guru'));
    }

    public function update(Request $request, $id)
    {
        $guru = Guru::findOrFail($id);
        $guru->update($request->all());
        return redirect()->route('dataguru.guru')->with('success', 'Data guru berhasil diperbarui.');
    }

    public function destroy($id)
    {
        $guru = Guru::findOrFail($id);
        $guru->delete();
        return redirect()->route('dataguru.guru')->with('success', 'Data guru berhasil dihapus.');
    }
}
